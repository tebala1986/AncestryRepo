//Mongoose schema implementation
var mongoose = require('mongoose');

var schema = mongoose.Schema;

var feedback_schema = new schema({
	name:String,
    email:String,
    age:Number,
    gender:String,
	country:String,
	scale:Number,
	suggestions:String,
    created_on:Date
}, { versionKey: false });

module.exports = mongoose.model('feedback',feedback_schema,'feedback');