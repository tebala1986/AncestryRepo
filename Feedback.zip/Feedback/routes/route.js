//Endpoint route configurations implementation
module.exports = function(app) {
	var feedback_service = require('../services/feedback_service.js');
     app.route('/feedback').get(feedback_service.get_feedback_report).post(feedback_service.save_feedback);
	 app.route('/getCountries').get(feedback_service.get_countries);
};