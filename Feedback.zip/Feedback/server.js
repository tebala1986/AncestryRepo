//Including node modules
var express = require('express');
var app = express();
var mongoose = require('mongoose');
var bodyParser = require('body-parser');

//Including App config
var settings = require('./config/settings');


var port = process.env.PORT || settings.applicationPort;
var db = mongoose.connect(settings.databaseUrl);
var objectId = mongoose.Types.ObjectId;

app.use(express.static(__dirname + '/./feedbackUI',{index:'index.html'}));

app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({ extended : true}));

require('./routes/route')(app);

console.log('Starting feedback app on port ' + port);

app.listen(port);

exports = module.exports = app;

