//Service method code implementation
var feedback = require('../models/feedback_model');

//Get Countries
exports.get_countries = function(req,res){
	var countries = require('../json/countries.json');
	res.json(countries);
};


//Feedback save method
exports.save_feedback = function(req,res) {
	var name = req.body.name;
	var email = req.body.email;
	var age = req.body.age;
	var gender = req.body.gender;
	var country = req.body.country;
	var scale = req.body.scale;
	var suggestions = req.body.suggestions;
	
	if(name != null && name!= undefined && name != "" && email != null && email!= undefined && email != ""){
		feedback.collection.insert({
			name:name,
			email:email,
			age:age,
			gender:gender,
			country:country,
			scale:scale,
			suggestions:suggestions,
			created_on:new Date()
		}, "", function(err, dbres) {
			if(!err)
				res.send({"success":true, "user_message":"Feedback saved successfully."});
			else 
				res.send({"success":false, "user_message":"Feedback save failed, please try again."});
		});
	}
	else
		res.send({"success":false, "user_message":"Please enter required data and try again."});
};

//Feedback report method
exports.get_feedback_report = function(req,res) {
	var from_date = req.query.fromdate;
    var to_date = req.query.todate;
    if (from_date != null && from_date != undefined && from_date != "" && to_date != null && to_date != undefined && to_date != "") {
        var start = from_date + ' 00:00:00';
        var end = to_date + ' 23:59:59';        
		feedback.find({created_on: {
        "$gte": new Date(start),
        "$lte": new Date(end)
		}}, function (err, result) {
			if (!err && result) {
				var totalAge = 0;
				var totalScale = 0;
				var maleCount = 0;
				var femaleCount = 0;
				var genderCount = 0;
				var ageCountNotNull = result.length;
				var scaleCountNotNull = result.length;
				var countries = [];
				for(var x = 0; x < result.length;x++){
					if(result[x].age != null)
						totalAge = totalAge + result[x].age;
					else
						ageCountNotNull -= 1;
					if(result[x].scale != null)
						totalScale = totalScale + result[x].scale;
					else
						scaleCountNotNull -= 1;
					if(result[x].gender != null){
						if(result[x].gender === "M")
							maleCount = maleCount + 1;
						if(result[x].gender === "F")
							femaleCount = femaleCount + 1;
					}
					else
						genderCount = genderCount + 1;
					if(result[x].country != null){						
						var isExist = false;
						for(var i=0; i < countries.length; i++){
							if (countries[i].name === result[x].country) {
								isExist = true;
								countries[i].count += 1;
								break;
							} 
						}
						if(!isExist){
							countries.push({name:result[x].country, count: 1});
						}						
					}
				}
				var calculatedResult = {
					"averageAge" : (totalAge/ageCountNotNull),
					"averageScale" : (totalScale/scaleCountNotNull),
					"maleGender": maleCount,
					"femaleGender": femaleCount,
					"countries": countries
				};
				res.send({"success":true, "user_message":"Data available.", "data":result, "calculated_data":calculatedResult});
			}
			else if (!err &&!result)
				res.send({"success":false, "user_message":"No data available."});
			else
				res.send({"success":false, "user_message":"Generating report failed."});
		});		
	}
	else
		res.send({"success":false, "user_message":"Input valid date and please try again."});
};